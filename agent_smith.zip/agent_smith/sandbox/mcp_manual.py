"""Manual of an MCP server's tools, resources and prompts for the LLM.

Pure transformation: JSON Schemas and server metadata in, text out. It does
not talk to any server, so it can be tested with plain dictionaries.
"""

from typing import Any

def manual(self) -> str:
    """Manual of the server's tools, resources and prompts for the LLM."""
    resources = ...   # self.list_resources(), con el try/except MCPError → []
    prompts = ...     # self.list_prompts(), igual
    return build_manual(self.list_tools(), resources, prompts)